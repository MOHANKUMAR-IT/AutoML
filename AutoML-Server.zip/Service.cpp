//#include <windows.h>
//#include <tchar.h>
//#include <strsafe.h>
//
//#include<stdlib.h>
//#include <string>
//
//#pragma comment(lib, "advapi32.lib")
//
//#define SVCNAME (LPWSTR)"AutoML-Load-Balancer"
//
//#define SVC_ERROR 1001001
//
//
////Syetm command ------------------
//
//#include <stdlib.h>
//
//using namespace std;
//#include <iostream>
//#include <fstream>
//
//#include "ErrorCodes.h"
//#include "AutoML-Server.h"
//
//SERVICE_STATUS          gSvcStatus;
//SERVICE_STATUS_HANDLE   gSvcStatusHandle;
//HANDLE                  ghSvcStopEvent = NULL;
//
//VOID SvcInstall(void);
//VOID __stdcall SvcDelete();
//VOID WINAPI SvcCtrlHandler(DWORD);
//VOID WINAPI SvcMain(DWORD, LPTSTR*);
//
//VOID ReportSvcStatus(DWORD, DWORD, DWORD);
//VOID SvcInit(DWORD, LPTSTR*);
//VOID SvcReportEvent(LPTSTR);
//
//VOID __stdcall SvcStop();
//
//bool CheckServiceExists();
//
//VOID SvcStart() {
//    string command = "sc start AutoML-Load-Balancer";
//    system(command.c_str());
//}
//VOID SvcStatus() {
//    string command = "sc query AutoML-Load-Balancer";
//    system(command.c_str());
//}
////
//// Purpose: 
////   Entry point for the process
////
//// Parameters:
////   None
//// 
//// Return value:
////   None, defaults to 0 (zero)
////
//int main(int argc, char* argv[])
//{
//
//    if (argc == 1) {
//        cout << "No Arguments given - -\n";
//    }
//    else if (strcmp(argv[1], (char*)"install") == 0)SvcInstall();
//    else if (strcmp(argv[1], (char*)"delete") == 0)SvcDelete();
//    else if (strcmp(argv[1], (char*)"stop") == 0)SvcStop();
//    else if (strcmp(argv[1], (char*)"start") == 0)SvcStart();
//    else if (strcmp(argv[1], (char*)"status") == 0)SvcStatus();
//    else {
//        cout << "Not valid argument" << argv[1]; return 0;
//    }
//    // TO_DO: Add any additional services for the process to this table.
//    SERVICE_TABLE_ENTRY DispatchTable[] =
//    {
//        { SVCNAME, (LPSERVICE_MAIN_FUNCTION)SvcMain },
//        { NULL, NULL }
//    };
//
//    // This call returns when the service has stopped. 
//    // The process should simply terminate when the call returns.
//
//    if (!StartServiceCtrlDispatcher(DispatchTable))
//    {
//        SvcReportEvent((LPWSTR)"StartServiceCtrlDispatcher");
//    }
//}
//std::string execute(std::string cmd)
//{
//    std::string file_name = "result.txt";
//    std::system((cmd + " > " + file_name).c_str()); // redirect output to file
//
//    // open file for input, return string containing characters in the file
//    std::ifstream file(file_name);
//    return { std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>() };
//}
//
//bool CheckServiceExists()
//{
//    string command = "sc query AutoML-Load-Balancer";
//    string result = execute(command);
//    cout << result;
//    string notPresent = "[SC] EnumQueryServicesStatus:OpenService FAILED 1060:\n\nThe specified service does not exist as an installed service.\n\n";
//    if (result == notPresent) {
//        return false;
//    }
//    return true;
//}
//
////
//// Purpose: 
////   Installs a service in the SCM database
////
//// Parameters:
////   None
//// 
//// Return value:
////   None
////
//VOID SvcInstall()
//{
//    LPWSTR szUnquotedPath = (LPWSTR)malloc(MAX_PATH);
//    if (!GetModuleFileName(NULL, szUnquotedPath, MAX_PATH))
//    {
//        printf("Cannot install service (%d)\n", GetLastError());
//        return;
//    }
//    wstring ws(szUnquotedPath);
//    string path = string(ws.begin(), ws.end());
//    string command = "sc create AutoML-Load-Balancer binpath=\"" + path + "\" type=own start=auto";
//    cout << command << endl;
//    std::system(command.c_str());
//    free(szUnquotedPath);
//}
//
////
//// Purpose: 
////   Stops the service.
////
//// Parameters:
////   None
//// 
//// Return value:
////   None
////
//VOID __stdcall SvcStop()
//{
//    string command = "sc stop AutoML-Load-Balancer";
//    std::system(command.c_str());
//}
//
//
//
////
//// Purpose: 
////   Deletes a service from the SCM database
////
//// Parameters:
////   None
//// 
//// Return value:
////   None
////
//VOID __stdcall SvcDelete()
//{
//    string command = "sc delete AutoML-Load-Balancer ";
//    std::system(command.c_str());
//}
//
////
//// Purpose: 
////   Entry point for the service
////
//// Parameters:
////   dwArgc - Number of arguments in the lpszArgv array
////   lpszArgv - Array of strings. The first string is the name of
////     the service and subsequent strings are passed by the process
////     that called the StartService function to start the service.
//// 
//// Return value:
////   None.
////
//VOID WINAPI SvcMain(DWORD dwArgc, LPTSTR* lpszArgv)
//{
//    // Register the handler function for the service
//
//    gSvcStatusHandle = RegisterServiceCtrlHandler(
//        SVCNAME,
//        SvcCtrlHandler);
//
//    if (!gSvcStatusHandle)
//    {
//        SvcReportEvent((LPTSTR)"RegisterServiceCtrlHandler");
//        return;
//    }
//
//    // These SERVICE_STATUS members remain as set here
//
//    gSvcStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
//    gSvcStatus.dwServiceSpecificExitCode = 0;
//
//    // Report initial status to the SCM
//
//    ReportSvcStatus(SERVICE_START_PENDING, NO_ERROR, 3000);
//
//    // Perform service-specific initialization and work.
//
//    SvcInit(dwArgc, lpszArgv);
//}
//
////
//// Purpose: 
////   The service code
////
//// Parameters:
////   dwArgc - Number of arguments in the lpszArgv array
////   lpszArgv - Array of strings. The first string is the name of
////     the service and subsequent strings are passed by the process
////     that called the StartService function to start the service.
//// 
//// Return value:
////   None
////
//VOID SvcInit(DWORD dwArgc, LPTSTR* lpszArgv)
//{
//    // TO_DO: Declare and set any required variables.
//    //   Be sure to periodically call ReportSvcStatus() with 
//    //   SERVICE_START_PENDING. If initialization fails, call
//    //   ReportSvcStatus with SERVICE_STOPPED.
//
//    // Create an event. The control handler function, SvcCtrlHandler,
//    // signals this event when it receives the stop control code.
//    ghSvcStopEvent = CreateEvent(
//        NULL,    // default security attributes
//        TRUE,    // manual reset event
//        FALSE,   // not signaled
//        NULL);   // no name
//
//    if (ghSvcStopEvent == NULL)
//    {
//        ReportSvcStatus(SERVICE_STOPPED, GetLastError(), 0);
//        return;
//    }
//
//    // Report running status when initialization is complete.
//
//    ReportSvcStatus(SERVICE_RUNNING, NO_ERROR, 0);
//
//    // TO_DO: Perform work until service stops.
//
//
//    // Check whether to stop the service.
//    HANDLE thHandle = CreateThread(NULL, 0, LoadBalancerService, NULL, 0, NULL);
//    //HANDLE ReporterServiceThread = CreateThread(NULL, 0, ResourceStatusReporter, NULL, 0, NULL);
//    WaitForSingleObject(ghSvcStopEvent, INFINITE);
//
//    ReportSvcStatus(SERVICE_STOPPED, NO_ERROR, 0);
//}
//
////
//// Purpose: 
////   Sets the current service status and reports it to the SCM.
////
//// Parameters:
////   dwCurrentState - The current state (see SERVICE_STATUS)
////   dwWin32ExitCode - The system error code
////   dwWaitHint - Estimated time for pending operation, 
////     in milliseconds
//// 
//// Return value:
////   None
////
//VOID ReportSvcStatus(DWORD dwCurrentState,
//    DWORD dwWin32ExitCode,
//    DWORD dwWaitHint)
//{
//    static DWORD dwCheckPoint = 1;
//
//    // Fill in the SERVICE_STATUS structure.
//
//    gSvcStatus.dwCurrentState = dwCurrentState;
//    gSvcStatus.dwWin32ExitCode = dwWin32ExitCode;
//    gSvcStatus.dwWaitHint = dwWaitHint;
//
//    if (dwCurrentState == SERVICE_START_PENDING)
//        gSvcStatus.dwControlsAccepted = 0;
//    else gSvcStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
//
//    if ((dwCurrentState == SERVICE_RUNNING) ||
//        (dwCurrentState == SERVICE_STOPPED))
//        gSvcStatus.dwCheckPoint = 0;
//    else gSvcStatus.dwCheckPoint = dwCheckPoint++;
//
//    // Report the status of the service to the SCM.
//    SetServiceStatus(gSvcStatusHandle, &gSvcStatus);
//}
//
////
//// Purpose: 
////   Called by SCM whenever a control code is sent to the service
////   using the ControlService function.
////
//// Parameters:
////   dwCtrl - control code
//// 
//// Return value:
////   None
////
//VOID WINAPI SvcCtrlHandler(DWORD dwCtrl)
//{
//    // Handle the requested control code. 
//
//    switch (dwCtrl)
//    {
//    case SERVICE_CONTROL_STOP:
//    {
//        ReportSvcStatus(SERVICE_STOP_PENDING, NO_ERROR, 0);
//        SetEvent(ghSvcStopEvent);
//        ReportSvcStatus(gSvcStatus.dwCurrentState, NO_ERROR, 0);
//
//        return;
//    }
//
//    case SERVICE_CONTROL_INTERROGATE:
//        break;
//
//    default:
//        break;
//    }
//
//}
//
////
//// Purpose: 
////   Logs messages to the event log
////
//// Parameters:
////   szFunction - name of function that failed
//// 
//// Return value:
////   None
////
//// Remarks:
////   The service must have an entry in the Application event log.
////
//VOID SvcReportEvent(LPTSTR szFunction)
//{
//    HANDLE hEventSource;
//    LPCTSTR lpszStrings[2];
//    TCHAR Buffer[80];
//
//    hEventSource = RegisterEventSource(NULL, SVCNAME);
//
//    if (NULL != hEventSource)
//    {
//        StringCchPrintf(Buffer, 80, TEXT("%s failed with %d"), szFunction, GetLastError());
//
//        lpszStrings[0] = SVCNAME;
//        lpszStrings[1] = Buffer;
//
//        ReportEvent(hEventSource,        // event log handle
//            EVENTLOG_ERROR_TYPE, // event type
//            0,                   // event category
//            100,           // event identifier
//            NULL,                // no security identifier
//            2,                   // size of lpszStrings array
//            0,                   // no binary data
//            lpszStrings,         // array of strings
//            NULL);               // no binary data
//
//        DeregisterEventSource(hEventSource);
//    }
//}