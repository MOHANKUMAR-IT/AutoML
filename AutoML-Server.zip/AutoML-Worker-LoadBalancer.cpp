// AutoML-Worker-LoadBalancer.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <unordered_map>
#include <string>
#include <nlohmann/json.hpp>

#include "HTTPRequest.hpp"
#include "AutoML-Server.h"

#include <boost/asio.hpp>
//Crow lib's

#include "crow.h"

#include "ErrorCodes.h"
#include <shared_mutex>

using namespace std;
using json = nlohmann::json;

bool HelpMeRetainState = true;


class WorkerNode {
public:
    string cpuUtil;
    string hostname;
    string memUtil;
    int numOfTasks = 0;
};

unordered_map<string, WorkerNode> NodeInfo;
std::shared_mutex map_mutex;

// Thread-safe function to insert an element into the map
void Mutex_Insert(const std::string& key, WorkerNode value)
{
    std::unique_lock<std::shared_mutex> lock(map_mutex);
    NodeInfo[key] = value;
}

// Thread-safe function to check if an element exists in the map
bool Mutex_Find(const std::string& key)
{
    std::shared_lock<std::shared_mutex> lock(map_mutex);
    return NodeInfo.count(key) > 0;
}

bool Mutex_Delete(const std::string& key) {
    std::shared_lock<std::shared_mutex> lock(map_mutex);
    
    auto it = NodeInfo.find(key);
    if (it != NodeInfo.end()) {
        NodeInfo.erase(it);
        cout << "\n\nDeleted Node -> " << key << "\n\n";
        return true;
    }
    else {
        return false;
    }
}

// Thread-safe function to get the value of an element from the map
WorkerNode Mutex_Get(const std::string& key)
{
    std::shared_lock<std::shared_mutex> lock(map_mutex);
    auto it = NodeInfo.find(key);
    if (it != NodeInfo.end()) {
        return it->second;
    }
    else {
        return WorkerNode(); // or some other error code
    }
}

void MagicPacketSender() {
    boost::asio::io_context io_context;

    boost::asio::ip::udp::socket socket(io_context);
    socket.open(boost::asio::ip::udp::v4());

    socket.set_option(boost::asio::socket_base::broadcast(true));

    std::string message = "Agents report status to me , ithuve en katalai katalai en sasanam !!!";

    boost::asio::ip::udp::endpoint broadcast_endpoint(boost::asio::ip::address_v4::broadcast(), 50505);
    socket.send_to(boost::asio::buffer(message), broadcast_endpoint);

    std::cout << "Sent broadcast packet: " << message << std::endl;
}

DWORD WINAPI DontMakeMeLonely(LPVOID lparam) {
    while (HelpMeRetainState) {
        if (NodeInfo.size() == 0) {
            MagicPacketSender();
        }
        Sleep(10000);
    }
    return 0;
}

string getFreeNode() {
    std::shared_lock<std::shared_mutex> lock(map_mutex);
    string addr = "";
    for (auto& node : NodeInfo) {
        if (addr == "" || node.second.memUtil > NodeInfo[addr].memUtil) {
            addr = node.first;
        }
    }
    return addr;
}

int allocateJob(string node,json InstructionSet) {
    http::Request request{ "http://" + node + ":10101/work" };
    std::string body = InstructionSet.dump();
    cout << "\n--------------------------------------\n\n";
    cout << node<<" "<<NodeInfo[node].hostname << endl;
    cout << body << endl;
    cout << "\n--------------------------------------\n\n";
    try
    { 
        const auto response = request.send("POST", body.c_str(), {
            {"Content-Type", "application/json"}
            });
        //std::cout << std::string{ response.body.begin(), response.body.end() } << '\n'; 
    }
    catch (const std::exception& e)
    {
        std::cerr << "Request failed, error: " << e.what() << '\n';
        return JOB_ALLOCATION_FAILURE;
    }
    
    return JOB_ALLOCATION_SUCCESS;
}

DWORD WINAPI CatContWork(LPVOID lparam) {

    json *insTypeP = (json*)(void*)lparam;
    json insType = *insTypeP;
    delete insTypeP;
    if (insType["methodType"] != "categorical") {
        for (int i = 0; i < 5; i++) {
            insType["value"] = i;
            int allocStatus = allocateJob(getFreeNode(), insType);
            //if (allocStatus != JOB_ALLOCATION_SUCCESS) {
            //    status = allocStatus; break;
            //}
            Sleep(5000);
        }
    }
    else {
        for (int i = 5; i < 10; i++) {
            insType["value"] = i;
            int allocStatus = allocateJob(getFreeNode(), insType);
            /*if (allocStatus != JOB_ALLOCATION_SUCCESS) {
                status = allocStatus; break;
            }*/
            Sleep(5000);
        }
    }
    //cout << "Status -> " << status << "\n\n";
    return 0;

}

DWORD WINAPI LoadBalancerService(LPVOID lparam)
{
    crow::SimpleApp app;
    CreateThread(NULL, 0, DontMakeMeLonely, NULL, 0, NULL);
    CROW_ROUTE(app, "/ClientStatusReport").methods("POST"_method)([&](const crow::request& req) {

        crow::json::rvalue x = crow::json::load(req.body);
        cout << "URL -> " << req.remote_ip_address << endl;
        cout << req.body << endl;
    if (!x)
        return crow::response(INVALID_JOB_INSTRUCTION);

        if (Mutex_Find(req.remote_ip_address) && x["status"] != "down") {
            WorkerNode w = Mutex_Get(req.remote_ip_address);
            w.memUtil = x["mem-util"].s();
            w.cpuUtil = x["cpu-util"].s();
            w.hostname = x["hostname"].s();
            cout << "Node -> " << w.hostname << endl;
            cout << "Resource Status Update ......\n\n";
            Mutex_Insert(req.remote_ip_address, w);
        }
        else if (x["status"] == "down") {
            cout << "Node -> " << req.remote_ip_address << endl;
            cout << "Status -> Down\n\n";
            for (auto& server : NodeInfo) {
                cout << server.second.hostname << server.second.memUtil << server.second.cpuUtil << "\n";
            }
            cout << "Printed\n\n";
            Mutex_Delete(req.remote_ip_address);
        }
        else {
            cout << "Node -> " << x["hostname"].s() << endl;
            cout << "Status -> Up\n\n";
            WorkerNode w = Mutex_Get(req.remote_ip_address);
            w.hostname = x["hostname"].s();
            w.cpuUtil = x["cpu-util"].s();
            w.memUtil = x["mem-util"].s();
            Mutex_Insert(req.remote_ip_address, w);
        }
        return crow::response({ 200 });
     
        });
    CROW_ROUTE(app, "/resource-details")([]() {
        crow::json::wvalue resourceUtilsation;
        resourceUtilsation["CPUused"] = "Hello";
        return resourceUtilsation;
        });
    CROW_ROUTE(app, "/ServerInfo")([&]() {
                    
        nlohmann::json temp;
        for (auto& server : NodeInfo) {
            temp[server.first]["hostname"] = server.second.hostname;
            temp[server.first]["mem-util"] = server.second.memUtil;
            temp[server.first]["cpu-util"] = server.second.cpuUtil;
            temp[server.first]["tasks"] = server.second.numOfTasks;
        }

        return temp.dump();
    });
    CROW_ROUTE(app, "/PrepareFile").methods("POST"_method)([&](const crow::request& req) {
        if (req.body == "")
            return crow::response({ INVALID_JOB_INSTRUCTION,"INVALID_FILE_INSTRUCTION" });
        json insType = json::parse(req.body);
        cout << req.body << endl;

        });
    CROW_ROUTE(app,"/work").methods("POST"_method)([&](const crow::request& req) {

        if (req.body=="")
            return crow::response({ INVALID_JOB_INSTRUCTION,"INVALID_JOB_INSTRUCTION"});
       
        

        if (NodeInfo.size() == 0) {
            return crow::response({ 500,"NO_WORKER_NODES_ARE_AVAILABLE" });
        }
;
        int status = JOB_ALLOCATION_SUCCESS;
        json *insType = new json(json::parse(req.body));
        HANDLE myWorker = CreateThread(NULL, 0, CatContWork, insType,NULL,NULL);

        if (status == JOB_ALLOCATION_SUCCESS)
            return crow::response({ 200,"WORK_STARTED" });
        else
            return crow::response({ INVALID_JOB_INSTRUCTION ,"INVALID_JOB_INSTRUCTION"+status });
       });
    app.port(18080).run();
    return 0;
}

int main() {
    // Check whether to stop the service.
    HANDLE thHandle = CreateThread(NULL, 0, LoadBalancerService, NULL, 0, NULL);
    //HANDLE ReporterServiceThread = CreateThread(NULL, 0, ResourceStatusReporter, NULL, 0, NULL);
    WaitForSingleObject(thHandle, INFINITE);
}