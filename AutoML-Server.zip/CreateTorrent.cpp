//#include "libtorrent/entry.hpp"
//#include "libtorrent/bencode.hpp"
//#include "libtorrent/torrent_info.hpp"
//#include "libtorrent/create_torrent.hpp"
//
//#include <functional>
//#include <cstdio>
//#include <sstream>
//#include <fstream>
//#include <iostream>
//
//#ifdef TORRENT_WINDOWS
//#include <direct.h> 
//#endif
//
//namespace {
//
//    using namespace std::placeholders;
//
//    std::vector<char> load_file(std::string const& filename)
//    {
//        std::fstream in;
//        in.exceptions(std::ifstream::failbit);
//        in.open(filename.c_str(), std::ios_base::in | std::ios_base::binary);
//        in.seekg(0, std::ios_base::end);
//        size_t const size = size_t(in.tellg());
//        in.seekg(0, std::ios_base::beg);
//        std::vector<char> ret(size);
//        in.read(ret.data(), int(ret.size()));
//        return ret;
//    }
//
//    std::string branch_path(std::string const& f)
//    {
//        if (f.empty()) return f;
//
//#ifdef TORRENT_WINDOWS
//        if (f == "\\\\") return "";
//#endif
//        if (f == "/") return "";
//
//        auto len = f.size();
//
//        if (f[len - 1] == '/' || f[len - 1] == '\\') --len;
//        while (len > 0) {
//            --len;
//            if (f[len] == '/' || f[len] == '\\')
//                break;
//        }
//
//        if (f[len] == '/' || f[len] == '\\') ++len;
//        return std::string(f.c_str(), len);
//    }
//
//    bool file_filter(std::string const& f)
//    {
//        if (f.empty()) return false;
//
//        char const* first = f.c_str();
//        char const* sep = strrchr(first, '/');
//#if defined(TORRENT_WINDOWS) || defined(TORRENT_OS2)
//        char const* altsep = strrchr(first, '\\');
//        if (sep == nullptr || altsep > sep) sep = altsep;
//#endif
//
//        if (sep == nullptr) sep = first;
//        else ++sep;
//
//        if (sep[0] == '.') return false;
//
//        std::cerr << f << "\n";
//        return true;
//    }
//
//} 
//
//int main(int argc_, char const* argv_[]) try
//{
//    std::string creator_str;
//    std::string comment_str;
//
//    std::vector<std::string> web_seeds;
//    std::vector<std::string> trackers;
//    std::vector<std::string> collections;
//    std::vector<lt::sha1_hash> similar;
//    int piece_size = 0;
//    lt::create_flags_t flags = {};
//    std::string root_cert;
//
//    std::string outfile;
//    
//    outfile = "a.torrent";
//
//
//    std::string full_path = "D:\\ubuntu-22.04.1-desktop-amd64.iso";
//    trackers.push_back("http:////localhost:8000//announce"); 
//    creator_str = "Mohan Kumar R - AutoML - Backend Engineer";
//    comment_str = "This file is used for ML training";
//    
//
//    lt::file_storage fs;
//#ifdef TORRENT_WINDOWS
//    if (full_path[1] != ':')
//#else
//    if (full_path[0] != '/')
//#endif
//    {
//        char cwd[2048];
//#ifdef TORRENT_WINDOWS
//#define getcwd_ _getcwd
//#else
//#define getcwd_ getcwd
//#endif
//
//        char const* ret = getcwd_(cwd, sizeof(cwd));
//        if (ret == nullptr) {
//            std::cerr << "failed to get current working directory: ";
//            return 1;
//        }
//
//#undef getcwd_
//#ifdef TORRENT_WINDOWS
//        full_path = cwd + ("\\" + full_path);
//#else
//        full_path = cwd + ("/" + full_path);
//#endif
//    }
//
//    lt::add_files(fs, full_path, file_filter, flags);
//    if (fs.num_files() == 0) {
//        std::cerr << "no files specified.\n";
//        return 1;
//    }
//
//    lt::create_torrent t(fs, piece_size, flags);
//    int tier = 0;
//    for (std::string const& tr : trackers) {
//        if (tr == "-") ++tier;
//        else t.add_tracker(tr, tier);
//    }
//
//    for (std::string const& ws : web_seeds)
//        t.add_url_seed(ws);
//
//    for (std::string const& c : collections)
//        t.add_collection(c);
//
//    for (lt::sha1_hash const& s : similar)
//        t.add_similar_torrent(s);
//
//    auto const num = t.num_pieces();
//    lt::set_piece_hashes(t, branch_path(full_path)
//        , [num](lt::piece_index_t const p) {
//            std::cerr << "\r" << p << "/" << num;
//        });
//
//    std::cerr << "\n";
//    t.set_creator(creator_str.c_str());
//    if (!comment_str.empty()) {
//        t.set_comment(comment_str.c_str());
//    }
//
//    if (!root_cert.empty()) {
//        std::vector<char> const pem = load_file(root_cert);
//        t.set_root_cert(std::string(&pem[0], pem.size()));
//    }
//
//    std::vector<char> torrent;
//    lt::bencode(back_inserter(torrent), t.generate());
//    if (!outfile.empty()) {
//        std::fstream out;
//        out.exceptions(std::ifstream::failbit);
//        out.open(outfile.c_str(), std::ios_base::out | std::ios_base::binary);
//        out.write(torrent.data(), int(torrent.size()));
//    }
//    else {
//        std::cout.write(torrent.data(), int(torrent.size()));
//    }
//
//    return 0;
//}
//catch (std::exception& e) {
//    std::cerr << "ERROR: " << e.what() << "\n";
//    return 1;
//}