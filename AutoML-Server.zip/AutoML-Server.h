#pragma once
#include <Windows.h>
DWORD WINAPI LoadBalancerService(LPVOID lparam);