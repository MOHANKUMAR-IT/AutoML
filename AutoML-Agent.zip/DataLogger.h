#pragma once

#include <string>
#include <fstream>
#include <windows.h>
#include <iostream>
#include <json/json.h>
#include <unordered_map>

using namespace std;

void logError(unordered_map<string, string> data);
void logData(unordered_map<string, string> data);

vector<string> readJson(string path);

void createLogFilesIfNotExists();