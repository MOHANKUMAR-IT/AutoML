#include <Windows.h>

#include <string>
#include <fstream>
#include <stdlib.h>

#include "DataLogger.h"
#include "NetworkAPI.h"
//#include "torrent.h"
#include <nlohmann/json.hpp>

using json = nlohmann::json;

#include <unordered_map>

using namespace std;

void writeDataToInstructionFile(string jsonInstruction) {
	std::string filename = "C:\\AutoML-Agent\\instruction.json";

	HANDLE hFile = CreateFile((LPCWSTR)filename.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	std::ofstream file(filename, std::ios::out | std::ios::trunc);

	if (!file.is_open()) {
		std::cerr << "Failed to open file " << filename << std::endl;
		return;
	}
	file << jsonInstruction << std::endl;
	file.close();
}
std::wstring utf8_to_wstring(const std::string& str)
{
	int size = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
	std::wstring wstr(size, 0);
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, &wstr[0], size);
	return wstr;
}

DWORD WINAPI createContainer(LPVOID lparam) {
	//unordered_map<string, string> *instruction = (unordered_map<string, string>*)(void*)lparam;
	
	//logErrorD["file-name"] = instruction->at("file-name");
	//HANDLE DownloadedStateEvent = DownloadFile((char*)(*instruction)["info-hash"].c_str(), true);

	

	/*if (WaitForSingleObject(DownloadedStateEvent, INFINITE) != WAIT_OBJECT_0) {
		logErrorD["Status"] = "Download Failed";
		logError(logErrorD);
		return 0;
	}
	logErrorD["Status"] = "Download Completed";
	logError(logErrorD);*/
	unordered_map<string, string> logErrorD;
	string* instructions = (string*)(void*)lparam;
	bool modified = false;
	for (int i = 0; i < instructions->size(); i++) {
		if ((*instructions)[i] == '"') {
			modified = true;
			instructions->insert(i, "\\"); i += 2;
		}
	}

	string inst_cmd_line = "docker run logiitg/machine_learning_image "+*instructions;
	
	/*for (unordered_map<string,string>::iterator it = instruction->begin(); it != instruction->end(); it++) {
		inst_cmd_line += " -"+it->first + " " + it->second;
	}*/

	delete instructions;


	logErrorD["Container Creation Command"] = inst_cmd_line;
	if (modified)logErrorD["Modified"] = "Yes";
	else logErrorD["Modified"] = "No";
	logError(logErrorD);

	//string instruction((char*)lparam);
	//writeDataToInstructionFile(instruction);
	//system(cmd.c_str());

	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	ZeroMemory(&pi, sizeof(pi));
	//si.dwFlags = STARTF_USESHOWWINDOW;
	//si.wShowWindow = SW_HIDE;
	std::wstring inst_cmd_line_wide = utf8_to_wstring(inst_cmd_line);
	WCHAR* commandLine = new WCHAR[inst_cmd_line_wide.size() + 1];
	wcscpy_s(commandLine, inst_cmd_line_wide.size() + 1, inst_cmd_line_wide.c_str());

	if (!CreateProcess(NULL, commandLine, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		cout << "Failed to start ML Trainer" << std::endl;
		return 1;
	}
	else {
		cout << "ML Trainer started\n";
	}
	
	while (WaitForSingleObject(pi.hProcess, 6000)!=WAIT_OBJECT_0) {
		Sleep(5000);
		ResourceStatusReporter();
	}
	
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	ResourceStatusReporter();
	return 0;
}

bool createMLTrainer(string *instructions) {

	/*char* inst = (char*)malloc(instructions.size()+1);
	memcpy(inst, instructions.c_str(), instructions.size());*/
	HANDLE temp;
	try {
		temp = CreateThread(NULL, 0, createContainer, instructions, NULL, NULL);
	}
	catch (int e) {
		e = 0;
	}
	unordered_map<string, string> logErrorD;
	logErrorD["Action"] = "Create ML Trainer";
	if (temp==NULL) {
		logErrorD["Status"] = "Failed";
		logError(logErrorD);
		return false;
	}
	logErrorD["Status"] = "Success";
	logError(logErrorD);
	return true;

}