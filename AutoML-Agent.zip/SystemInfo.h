#pragma once
#include <string>

std::string HostName();
unsigned long long MemUtilisation();
float CPUUtilisation();
