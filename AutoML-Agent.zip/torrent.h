#pragma once
HANDLE DownloadFile(char* torrent, bool isMagnet);