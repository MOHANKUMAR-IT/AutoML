//CurlCpp lib's

#include <stdio.h>
#include <curl/curl.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
#include <string>

#include "HTTPRequest.hpp"

#include <Winsock2.h>
#include <ws2tcpip.h>
#include <Windows.h>    

#include "ErrorCodes.h"
#include <string> 
#pragma comment(lib, "Ws2_32.lib")

#include <unordered_map>

//Crow lib's

#include "crow.h"


// Mine

#include "ErrorCodes.h"
#include "SystemInfo.h"
#include "SystemControl.h"
#include "NetworkAPI.h"
#include "DataLogger.h"



#include <boost/asio.hpp>

int ReportStatus = 1;

DWORD WINAPI MagicPacketListner(LPVOID lparam) {
    boost::asio::io_context io_context;

    boost::asio::ip::udp::socket socket(io_context);
    socket.open(boost::asio::ip::udp::v4());

    socket.set_option(boost::asio::socket_base::broadcast(true));

    boost::asio::ip::udp::endpoint local_endpoint(boost::asio::ip::udp::v4(), 50505);
    socket.bind(local_endpoint);

    std::cout << "Listening for broadcast packets...\n";
    char data[1024];
    boost::asio::ip::udp::endpoint sender_endpoint;
    unordered_map<string, string> logD = { {"Magic Packet","Received"}};
    while (true) {
        std::size_t nbytes = socket.receive_from(boost::asio::buffer(data), sender_endpoint);
        ResourceStatusReporter();
        logError(logD);
        std::cout << "Received packet from " << sender_endpoint.address().to_string()
            << ":" << sender_endpoint.port() << " - " << data << std::endl;
    }

    return 0;
}


DWORD WINAPI reportStatusToServer(LPVOID lparam)
{
    std::unordered_map<std::string, std::string>* data = (std::unordered_map<std::string, std::string>*)(void*)lparam;
    if((*data)["status"] == "down")ReportStatus = 0;

    try
    {
        http::Request request{ "http://mohan-kumar-r:18080/ClientStatusReport"};
        
        json reportVals = {};
        for (auto& data_key_val : *data) {

            reportVals[data_key_val.first] = data_key_val.second;
        }
        logError(*data);
        const std::string body = reportVals.dump();
        const auto response = request.send("POST", body, {
            {"Content-Type", "application/json"}
            });
        //std::cout << std::string{ response.body.begin(), response.body.end() } << '\n'; // print the result4
        data->clear();
        
        (*data)["Server received"] = response.status.reason;
        (*data)["Server Response"] = (int)response.status.code;
        logError(*data);
        return STATUS_REPORT_TO_SERVER_SUCCESS;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Request failed, error: " << e.what() << '\n';
        (*data)["Error occured for this report"] = e.what();
        logError(*data);
        return STATUS_REPORT_TO_SERVER_FAILED;
    }
    return STATUS_REPORT_TO_SERVER_FAILED;
    /*CURL* curl;
    CURLcode res;

    if (data["status"] == "down")ReportStatus = 0;

    curl_global_init(CURL_GLOBAL_ALL);

    curl = curl_easy_init();
    if (curl) {
        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, "Accept: application/json");
        headers = curl_slist_append(headers, "Content-Type: application/json");
        headers = curl_slist_append(headers, "charset: utf-8");
        json j_object ={};
        for (auto& data_key_val : data) {

            j_object[data_key_val.first] = data_key_val.second;
        }
        std::string json_str = j_object.dump();

        std::cout << json_str << std::endl;

        curl_easy_setopt(curl, CURLOPT_URL, "http://mohan-kumar-r:18080/ClientStatusReport");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json_str.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, json_str.size());

        res = curl_easy_perform(curl);

        curl_easy_cleanup(curl);

        if (res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            return STATUS_REPORT_TO_SERVER_FAILED;
        }
    }
    curl_global_cleanup();
    return STATUS_REPORT_TO_SERVER_SUCCESS;*/
}


int ResourceStatusReporter() {
    std::unordered_map<std::string, std::string> data = { {"hostname",HostName()},{"status","up" },{"cpu-util",std::to_string(CPUUtilisation())},{"mem-util",std::to_string(MemUtilisation())} };
    DWORD ThreadID = 0;
    HANDLE threadHandle = CreateThread(NULL, 0, reportStatusToServer, &data, 0, &ThreadID);
    if (WaitForSingleObject(threadHandle, 5000) != WAIT_OBJECT_0) {
        TerminateThread(threadHandle, NULL);
        return STATUS_REPORT_TO_SERVER_FAILED;
    }
    return STATUS_REPORT_TO_SERVER_SUCCESS;
}

DWORD WINAPI ResourceStatusReporterThread(LPVOID lParam) {

    while (ReportStatus) {
        std::unordered_map<std::string, std::string> data = { {"hostname",HostName()},{"status","up" },{"cpu-util",std::to_string(CPUUtilisation())},{"mem-util",std::to_string(MemUtilisation())} };

        try {
            DWORD ThreadID = 0;
            HANDLE threadHandle = CreateThread(NULL, 0, reportStatusToServer, &data, 0, &ThreadID);
            if (WaitForSingleObject(threadHandle, 6000) != WAIT_OBJECT_0) {
                TerminateThread(threadHandle, NULL);
                //return STATUS_REPORT_TO_SERVER_FAILED;
            }
        }
        catch (int e) {
            std::cout << "Server Report Failed with err ->"+std::to_string(e)+" .....\n Trying again in next cycle...\n\n";
        }
        Sleep(10000);
    }
    return 0;
}



DWORD WINAPI AgentAPIService(LPVOID lParam){
    std::unordered_map <std::string, std::string> Status;// = (std::unordered_map <std::string, std::string>*)malloc(sizeof(std::unordered_map <std::string, std::string>));
    CreateThread(NULL, 0, MagicPacketListner, NULL, 0, NULL);
    CreateThread(NULL, 0, ResourceStatusReporterThread, NULL, NULL, NULL);
    Status["status"]="up";
    logError(Status);
    /*while (true) { 
        try {
            DWORD ThreadID = 0;
            HANDLE threadHandle = CreateThread(NULL, 0, reportStatusToServer, &Status, 0, &ThreadID);
            if (WaitForSingleObject(threadHandle, 3000) != WAIT_OBJECT_0) {
                TerminateThread(threadHandle, NULL);
            }
            else break;
            Status["Retrying"] = "Yes";
            logError(Status);
        }
        catch (int e) {
            Status["Error"] = e;
            logError(Status);
        }

    }*/
    /*while (ResourceStatusReporter() != STATUS_REPORT_TO_SERVER_SUCCESS) { Sleep(3000); };
    */
    Status.clear();
    Status["Reported to Server"] = "Yes";
    logError(Status);

    crow::SimpleApp app;
   
    CROW_ROUTE(app, "/work").methods("POST"_method)([&](const crow::request& req) {

        json jobj = json::parse(req.body);
        string* data = new string();
        *data = jobj.dump();
        unordered_map<string, string> lgData;
        if (data->size() == 0) {
            lgData["Status"] = "Failed";
            lgData["Instruction"] = *data;
            logError(lgData);
            return crow::response(INVALID_JOB_INSTRUCTION);
        }
        
        try {
            /*unordered_map<string, string>* instructionSet = new unordered_map<string, string>();
            while(instructionSet == NULL) {
                instructionSet = new unordered_map<string, string>();
            }*/
            /*instructionSet->operator[]("instruction-set") = data;
            logData(*instructionSet);*/
            //instructionSet->clear();
            /*instructionSet->operator[]("timestamp") = jobj["timestamp"];
            instructionSet->operator[]("methodType") = jobj["methodType"];
            instructionSet->operator[]("email") = jobj["email"];
            instructionSet->operator[]("value") = jobj["value"];*/
            //logData(*instructionSet);
            lgData["instruction-set"] = *data;
            logData(lgData);
            int retry = 3;

            while (retry--) {
                if (createMLTrainer(data))break;
            }
            //logData(*instructionSet);
        }
        catch (int e) {
            lgData.clear();
            lgData["ML Trainer"] = "Failed to Start :(";
            lgData["Error Occired"] = e;
            logError(lgData);
            return  crow::response({ 500 });
        }


        return crow::response({ 200 });
        

    });

    app.port(10101).run();

    return 0;
}