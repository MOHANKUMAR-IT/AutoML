#pragma once

#include <unordered_map>
#include <string>

DWORD WINAPI AgentAPIService(LPVOID lParam);
int ResourceStatusReporter();
DWORD reportStatusToServer(LPVOID lparam);