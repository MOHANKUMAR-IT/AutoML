//#include <iostream>
//#include <thread>
//#include <chrono>
//#include <fstream>
//
//#include <libtorrent/session.hpp>
//#include <libtorrent/session_params.hpp>
//#include <libtorrent/add_torrent_params.hpp>
//#include <libtorrent/torrent_handle.hpp>
//#include <libtorrent/alert_types.hpp>
//#include <libtorrent/bencode.hpp>
//#include <libtorrent/torrent_status.hpp>
//#include <libtorrent/read_resume_data.hpp>
//#include <libtorrent/write_resume_data.hpp>
//#include <libtorrent/error_code.hpp>
//#include <libtorrent/magnet_uri.hpp>
//
//#include <map>
//#include <string>
//#include <mutex>
//
//namespace {
//
//    using clk = std::chrono::steady_clock;
//
//    // return the name of a torrent status enum
//    char const* state(lt::torrent_status::state_t s)
//    {
//        switch (s) {
//        case lt::torrent_status::checking_files: return "checking";
//        case lt::torrent_status::downloading_metadata: return "dl metadata";
//        case lt::torrent_status::downloading: return "downloading";
//        case lt::torrent_status::finished: return "finished";
//        case lt::torrent_status::seeding: return "seeding";
//        case lt::torrent_status::checking_resume_data: return "checking resume";
//        default: return "<>";
//        }
//    }
//
//} // anonymous namespace
//lt::settings_pack pack;
//lt::session ses;
//bool initialised = false, clienStarted = false;
//
//std::map<std::string, HANDLE> TorrentCompletionEvent;
//
//HANDLE DownloadTorrent(char*& torrent, bool isMagnet) {
//
//    lt::add_torrent_params magnet;
//    if (!isMagnet) {
//        magnet.ti = std::make_shared<lt::torrent_info>(torrent);
//    }
//    else {
//        magnet = lt::parse_magnet_uri(torrent);
//    }
//    magnet.save_path = "d:\\torrentDownloads\\";
//
//    lt::torrent_handle torHandle = ses.add_torrent(std::move(magnet));
//    libtorrent::torrent_status const& ts = torHandle.status();
//    std::string const& name = ts.name;
//    std::cout << "Torrent started -> " << name << "\n\n";
//    HANDLE torEvent = CreateEvent(NULL, TRUE, FALSE, (LPCWSTR)name.c_str());
//    TorrentCompletionEvent["over"] = torEvent;
//    return torEvent;
//}
//
//
//
//DWORD WINAPI WaitAndRemoveTorrent(LPVOID lparam) {
//    const lt::torrent_finished_alert* tfa = (const lt::torrent_finished_alert*)(void*)lparam;
//    std::string torName = tfa->handle.status().name;
//    std::vector<lt::torrent_handle> handles = ses.get_torrents();
//
//    lt::torrent_handle torHandle;
//    bool flag = false;
//    for (int i = 0; i < handles.size(); i++) {
//        std::cout << "Handle for _>>>>>>>>>" << handles[i].status().name << "----" << torName << "\n\n";
//        if (handles[i].status().name == torName) {
//            torHandle = handles[i];
//            flag = true;
//            break;
//        }
//    }
//    if (!flag) {
//        std::cout << "Invalid Handle\n\n";
//        SetEvent(TorrentCompletionEvent[torName]);
//        return 0;
//    }
//    std::cout << "\n\nTorrent -> " << torName << "\n\n";
//    std::cout << "   Status -> " << "Completed\n";
//    std::cout << "   Seeding for 5Mins .....\n\n";
//
//    Sleep(1000);
//    std::cout << "\n\nRemoving Torrent -> " << torName << " !!!\n";
//    for (auto i : TorrentCompletionEvent) {
//        std::cout << i.first << "\n\n";
//    }
//    if (TorrentCompletionEvent.find(torName) != TorrentCompletionEvent.end())
//        TorrentCompletionEvent.erase(torName);
//
//
//    std::cout << "Status -> " << "Removed\n\n";
//
//    SetEvent(TorrentCompletionEvent["over"]);
//    ses.remove_torrent(torHandle);
//    return 0;
//}
//
//
//DWORD WINAPI runClient(LPVOID param)
//{
//    try {
//
//
//        lt::torrent_handle h;
//
//        bool done = false;
//        for (;;) {
//            std::vector<lt::alert*> alerts;
//            ses.pop_alerts(&alerts);
//
//            for (lt::alert const* a : alerts) {
//                if (auto at = lt::alert_cast<lt::add_torrent_alert>(a)) {
//                    h = at->handle;
//                }
//
//                if (const lt::torrent_finished_alert* tfa = lt::alert_cast<lt::torrent_finished_alert>(a)) {
//                    std::cout << "Finish Alert\n";
//                    h = tfa->handle;
//                    //SetEvent(TorrentCompletionEvent[h.status().name]);
//                    std::cout << "Torrent -> " << h.status().name << "Downloaded\n\n";
//                    /*char* name = (char*)malloc(h.status().name.size());
//                    memcpy(name, (char*)h.status().name.c_str(), h.status().name.size());
//                    */
//                    CreateThread(NULL, 0, WaitAndRemoveTorrent, (void*)tfa, NULL, NULL);
//                }
//
//            }
//            std::this_thread::sleep_for(std::chrono::milliseconds(2000));
//
//            ses.post_torrent_updates();
//
//        }
//    }
//    catch (std::exception& e)
//    {
//        std::cerr << "Error: " << e.what() << std::endl;
//    }
//    return 0;
//}
//
//
//HANDLE DownloadFile(char* torrent, bool isMagnet) {
//    if (!initialised) {
//        pack.set_int(lt::settings_pack::alert_mask, lt::alert_category::error | lt::alert_category::storage | lt::alert_category::status);
//        ses.apply_settings(pack);
//        initialised = true;
//    }
//    if (!clienStarted) {
//        CreateThread(NULL, 0, runClient, NULL, 0, NULL);
//    }
//
//    return DownloadTorrent(torrent, isMagnet);
//}
