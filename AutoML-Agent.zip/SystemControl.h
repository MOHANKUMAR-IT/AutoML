#pragma once
#include <string>


//bool createMLTrainer(std::unordered_map<std::string, std::string> *instructions);
bool createMLTrainer(std::string* inst);