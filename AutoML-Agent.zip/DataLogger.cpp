
#include "DataLogger.h"

using namespace std;

SYSTEMTIME st, lt;

void log(unordered_map<string, string>& data, string path) {
    GetLocalTime(&lt);

    Json::Value newValue;
    for (auto i : data) {
        newValue[i.first] = i.second;
    }
    newValue["day"] = to_string(lt.wDay) + "/" + to_string(lt.wMonth) + "/" + to_string(lt.wYear);
    newValue["time"] = to_string(lt.wHour) + ":" + to_string(lt.wMinute);
    // Open the existing JSON file
    std::fstream jsonFile(path, std::ios::in | std::ios::out);

    // Parse the JSON file
    Json::Value root;
    Json::CharReaderBuilder builder;
    std::string errors;
    Json::parseFromStream(builder, jsonFile, &root, &errors);

    // Append the new value to the root of the JSON object
    root.append(newValue);

    // Write the modified JSON object back to the file
    jsonFile.seekp(0);
    jsonFile << root;

    jsonFile.close();

}

vector<string> readJson(string path) {
    std::ifstream jsonFile(path);
    Json::Value root;
    Json::Reader reader;
    bool parsingSuccessful = reader.parse(jsonFile, root);
    if (!parsingSuccessful) {
        return {};
    }
    vector<string> res;
    for (unsigned int i = 0; i < root.size(); i++) {
        res.push_back(root[i].asString());
    }
    return res;
}

void createLogFilesIfNotExists() {
    LPCWSTR folderName = L"C:\\AutoML-Agent";
    LPCWSTR fileName1 = L"C:\\AutoML-Agent\\ErrorLogs.json";
    LPCWSTR fileName2  = L"C:\\AutoML-Agent\\DataLogs.json";
    // create folder if it does not exist
    if (!CreateDirectory(folderName, NULL) && ERROR_ALREADY_EXISTS != GetLastError()) {
        // handle error if folder creation fails
        return;
    }

    // create file if it does not exist
    HANDLE hFile = CreateFile(fileName1, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        // handle error if file creation fails
        return;
    }
    CloseHandle(hFile);
    hFile = CreateFile(fileName2, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        // handle error if file creation fails
        return;
    }

    // close the file handle
    CloseHandle(hFile);

    // the folder and file have been created or already exist
    return;
}




void logError(unordered_map<string, string> data) {

    string path = "C:\\AutoML-Agent\\ErrorLogs.json";
    log(data, path);
}

void logData(unordered_map<string, string> data) {

    string path = "C:\\AutoML-Agent\\DataLogs.json";
    log(data, path);

}